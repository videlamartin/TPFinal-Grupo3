<?php
class PartidaController
{
    const DURACION_RULETA_SEGUNDOS = 4;
    private $partidaModel;
    private $preguntaModel;
    private $usuarioModel;
    private $renderer;
    private $request;
    private $categoriaModel;

    private $usuarioSesion;
    private $reporteModel;
    private $usuarioPreguntaModel;

    public function __construct($partidaModel, $preguntaModel, $usuarioModel,$categoriaModel, $renderer, $request, $usuarioSesion, $reporteModel, $usuarioPreguntaModel)
    {
        $this->partidaModel = $partidaModel;
        $this->preguntaModel = $preguntaModel;
        $this->usuarioModel = $usuarioModel;
        $this->categoriaModel = $categoriaModel;
        $this->renderer = $renderer;
        $this->request = $request;
        $this->usuarioSesion = $usuarioSesion;
        $this->reporteModel = $reporteModel;
        $this->usuarioPreguntaModel = $usuarioPreguntaModel;

    }

    public function iniciar()
    {
        if (isset($_SESSION['partida'])) {
            Redirect::to('/partida/pregunta');
        }
        $usuario = $this->usuarioModel->buscarPorId($this->usuarioSesion['id']);
        $nivelUsuario = $this->usuarioModel->calcularNivelUsuario($usuario);
        $partidaId = $this->partidaModel->crearPartida($this->usuarioSesion['id']);
        $categoria = $this->categoriaModel->obtenerCategoriaRandom();
        $_SESSION['partida'] = [
            'partida_id'         => $partidaId,
            'pregunta_actual_id' => null,
            'tiempo_inicio'      => null,
            'tiempo_limite'      => 30,
            'nivel_usuario'      => $nivelUsuario,
            'correctas_esta_partida' => 0,
        ];
        Redirect::to('/partida/pregunta');
    }

    public function pregunta()
    {
        if (!$this->usuarioSesion['id']) Redirect::to('/login/ver');
        if (!isset($_SESSION['partida']))    Redirect::to('/lobby/ver');

        $pregunta = $this->obtenerOSortearPregunta();

        if (!$pregunta) {
            $this->finalizarPartida('sin_preguntas');
            return;
        }

        $tiempoFin = $_SESSION['partida']['tiempo_inicio'] + $_SESSION['partida']['tiempo_limite'];

        $this->renderer->render('juego', [
            'pregunta'        => $pregunta['enunciado'],
            'pregunta_id'     => $pregunta['id'],
            'categoria'       => $pregunta['categoria_nombre'],
            'categoria_color' => $pregunta['categoria_color'],
            'categoria_actual'=> $_SESSION['partida']['categoria_actual'],
            'categoria_color_actual' => $_SESSION['partida']['categoria_color'],
            'respuestas'      => $this->preguntaModel->obtenerRespuestas($pregunta['id']),
            'tiempo_restante' => $this->calcularTiempoRestante(),
            'tiempo_limite'   => $_SESSION['partida']['tiempo_limite'],
            'tiempo_fin'      => $tiempoFin * 1000, // milisegundos para JS
            'puntaje_actual'  => $this->partidaModel->obtenerPorId($_SESSION['partida']['partida_id'])['puntaje']
        ]);
    }

    public function responder()
    {
        if (!$this->usuarioSesion['id'] || !isset($_SESSION['partida'])) {
            Redirect::to('/login/ver');
        }

        if ($this->tiempoVencido()) {
            $this->finalizarPartida('tiempo');
            return;
        }

        $respuestaId = (int) $_POST['respuesta_id'];
        $respuesta = $this->preguntaModel->verificarRespuesta($respuestaId);


        if (!$respuesta) {
            $this->finalizarPartida('tiempo');
            return;
        }

        // En vez de avanzar o terminar de una, guardamos la eleccion y
        // redirigimos a una pantalla de revelacion (por GET, para que se
        // pueda recargar sin re-enviar la respuesta ni cortar por tiempo).
        $_SESSION['partida']['revelacion'] = [
            'elegida_id'  => $respuestaId,
            'es_correcta' => (bool) $respuesta['es_correcta'],
        ];

        Redirect::to('/partida/revelacion');
    }

    // Pantalla intermedia: muestra la pregunta con la respuesta correcta
    // resaltada. No corre el tiempo. El boton "Siguiente" llama a continuar().
    public function revelacion()
    {
        if (!$this->usuarioSesion['id'] || !isset($_SESSION['partida'])) {
            Redirect::to('/login/ver');
        }
        if (!isset($_SESSION['partida']['revelacion'])) {
            Redirect::to('/partida/pregunta');
        }

        $rev        = $_SESSION['partida']['revelacion'];
        $preguntaId = $_SESSION['partida']['pregunta_actual_id'];
        $pregunta   = $this->preguntaModel->obtenerPorId($preguntaId);
        $respuestas = $this->preguntaModel->obtenerRespuestas($preguntaId);

        foreach ($respuestas as &$r) {
            $correcta = (bool) $r['es_correcta'];
            $elegida  = ($r['id'] == $rev['elegida_id']);
            $r['marca_correcta']   = $correcta;
            $r['marca_incorrecta'] = $elegida && !$correcta;
        }
        unset($r);

        $this->renderer->render('revelacion', [
            'pregunta'         => $pregunta['enunciado'],
            'categoria'        => $pregunta['categoria_nombre'],
            'categoria_color'  => $pregunta['categoria_color'],
            'categoria_actual' => $_SESSION['partida']['categoria_actual'],
            'respuestas'       => $respuestas,
            'es_correcta'      => $rev['es_correcta'],
            'puntaje_actual'   => $this->partidaModel->obtenerPorId($_SESSION['partida']['partida_id'])['puntaje'],
        ]);
    }

    // Se llama desde el boton "Siguiente" de la pantalla de revelacion.
    // Si acerto, suma el punto y va a la proxima pregunta.
    // Si erro, termina la partida (mostrando la respuesta correcta).
    public function continuar()
    {
        if (!$this->usuarioSesion['id'] || !isset($_SESSION['partida'])) {
            Redirect::to('/login/ver');
        }
        if (!isset($_SESSION['partida']['revelacion'])) {
            Redirect::to('/partida/pregunta');
        }

        $esCorrecta = $_SESSION['partida']['revelacion']['es_correcta'];
        unset($_SESSION['partida']['revelacion']);

        if ($esCorrecta) {
            $this->procesarAcierto();
            Redirect::to('/partida/pregunta');
        } else {
            $correcta = $this->preguntaModel->obtenerRespuestaCorrecta(
                $_SESSION['partida']['pregunta_actual_id']
            );
            $this->finalizarPartida('incorrecta', $correcta['texto']);
        }
    }

    private function obtenerOSortearPregunta()
    {
        if ($_SESSION['partida']['pregunta_actual_id'] !== null) {
            return $this->preguntaModel->obtenerPorId(
                $_SESSION['partida']['pregunta_actual_id']
            );
        }

        $usuarioId = $this->usuarioSesion['id'];

        // Resetear
        $totalPreguntas = $this->preguntaModel->contarAprobadas();
        $this->usuarioPreguntaModel->resetearSiSinPreguntas($usuarioId, $totalPreguntas);

        //ids ya vistos desde la base
        $preguntasVistas = $this->usuarioPreguntaModel->obtenerIdsVistas($usuarioId);

        $categoria = $this->categoriaModel->obtenerCategoriaRandom();
        $_SESSION['partida']['categoria_actual'] = $categoria['nombre'];
        $_SESSION['partida']['categoria_color']  = $categoria['color'];
        $_SESSION['partida']['categoria_id']     = $categoria['id'];

        $pregunta = $this->preguntaModel->obtenerPreguntaParaUsuario(
            $_SESSION['partida']['nivel_usuario'],
            $preguntasVistas,        // <-- antes era $_SESSION['partida']['preguntas_vistas']
            $_SESSION['partida']['categoria_id']
        );

        if (!$pregunta) return null;

        $_SESSION['partida']['pregunta_actual_id'] = $pregunta['id'];
        $_SESSION['partida']['tiempo_inicio'] = time() + self::DURACION_RULETA_SEGUNDOS;
        $this->preguntaModel->registrarMostrada($pregunta['id']);

        return $pregunta;
    }

    private function tiempoVencido()
    {
        $transcurrido = time() - $_SESSION['partida']['tiempo_inicio'];
        return $transcurrido > $_SESSION['partida']['tiempo_limite'];
    }

    private function calcularTiempoRestante()
    {
        $transcurrido = time() - $_SESSION['partida']['tiempo_inicio'];
        return max(0, $_SESSION['partida']['tiempo_limite'] - $transcurrido);
    }

    private function procesarAcierto()
    {
        $preguntaId = $_SESSION['partida']['pregunta_actual_id'];
        $partidaId  = $_SESSION['partida']['partida_id'];

        $this->partidaModel->sumarPunto($partidaId);
        $this->preguntaModel->registrarCorrecta($preguntaId);

        // Guardar en base en vez de en sesión
        $this->usuarioPreguntaModel->registrarVista(
            $this->usuarioSesion['id'],
            $preguntaId
        );

        $_SESSION['partida']['pregunta_actual_id'] = null;
        $_SESSION['partida']['tiempo_inicio']      = null;
        $_SESSION['partida']['correctas_esta_partida']++;
    }

    private function finalizarPartida($motivo, $respuestaCorrecta = null)
    {
        $partida = $this->partidaModel->obtenerPorId($_SESSION['partida']['partida_id']);
        $this->partidaModel->finalizar($partida['id']);

        // Sumar puntaje y estadisticas al perfil del usuario.
        // Las correctas son las preguntas que se fueron acumulando en
        // 'preguntas_vistas'. Si perdio por responder mal, esa ultima
        // pregunta tambien cuenta como respondida (pero no como correcta).
        $respuestasCorrectas  = $_SESSION['partida']['correctas_esta_partida'];
        $preguntasRespondidas = $respuestasCorrectas + ($motivo === 'incorrecta' ? 1 : 0);

        $this->usuarioModel->sumarPuntaje(
            $this->usuarioSesion['id'],
            $partida['puntaje'],
            $preguntasRespondidas,
            $respuestasCorrectas
        );

        // Mantener actualizado el puntaje que se muestra en el lobby/sesion
        $_SESSION['puntaje_total'] += $partida['puntaje'];

        // La pregunta en la que terminó la partida es la "reportable".
        // (Si terminó por quedarse sin preguntas, no hay ninguna, queda null.)
        $preguntaReportableId = $_SESSION['partida']['pregunta_actual_id'];

        $datos = [
            'puntaje'                => $partida['puntaje'],
            'motivo_fin'             => $motivo,
            'respuesta_correcta'     => $respuestaCorrecta,
            'pregunta_reportable_id' => $preguntaReportableId
        ];

        if ($_SESSION['partida']['pregunta_actual_id']) {
            $this->usuarioPreguntaModel->registrarVista(
                $this->usuarioSesion['id'],
                $_SESSION['partida']['pregunta_actual_id']
            );
        }

        unset($_SESSION['partida']);
        $this->renderer->render('resultado', $datos);
    }

    public function reportar()
    {
        if (!$this->usuarioSesion['id']) {
            Redirect::to('/login/ver');
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            Redirect::to('/lobby/ver');
        }

        $preguntaId = (int) $_POST['pregunta_id'];
        $motivo     = trim($_POST['motivo'] ?? '');

        if ($preguntaId > 0) {
            $this->reporteModel->crear(
                $preguntaId,
                $this->usuarioSesion['id'],
                $motivo !== '' ? $motivo : null
            );
        }

        // Vuelve a mostrar la pantalla de resultado, ahora con la confirmacion.
        $this->renderer->render('resultado', [
            'puntaje'    => (int) ($_POST['puntaje'] ?? 0),
            'motivo_fin' => $_POST['motivo_fin'] ?? '',
            'reportado'  => true
        ]);
    }




}