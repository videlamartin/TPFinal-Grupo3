<?php

class RegistroController
{
    private $usuarioModel;
    private $renderer;
    private $request;
    private $mailUsername;
    private $mailPassword;

    public function __construct($usuarioModel, $renderer, $request, $mailUsername, $mailPassword)
    {
        $this->usuarioModel  = $usuarioModel;
        $this->renderer      = $renderer;
        $this->request       = $request;
        $this->mailUsername  = $mailUsername;
        $this->mailPassword  = $mailPassword;
    }

    public function ver()
    {
        $datos = [];

        if (isset($_SESSION['error'])) {
            $datos['error'] = $_SESSION['error'];
            unset($_SESSION['error']);
        }

        $this->renderer->render("registro", $datos);
    }

    public function registrar()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            Redirect::to('/registro/ver');
        }

        // Validaciones server-side
        $errores = $this->validar($_POST);
        if (!empty($errores)) {
            $_SESSION['error'] = implode(', ', $errores);
            Redirect::to('/registro/ver');
        }

        // Manejo de foto de perfil
        $fotoPerfil = null;
        if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
            $fotoPerfil = $this->subirFoto($_FILES['foto_perfil']);
        }

        $datos = [
            'nombre_completo' => trim($_POST['nombre_completo']),
            'anio_nacimiento' => (int) $_POST['anio_nacimiento'],
            'sexo'            => $_POST['sexo'],
            'pais'            => trim($_POST['pais']),
            'ciudad'          => trim($_POST['ciudad']),
            'email'           => trim($_POST['email']),
            'password'        => $_POST['password'],
            'username'        => trim($_POST['username']),
            'foto_perfil'     => $fotoPerfil
        ];

        $resultado = $this->usuarioModel->registrar($datos);

        if (isset($resultado['error'])) {
            $_SESSION['error'] = $resultado['error'];
            header('Location: /registro/ver');
            exit();
        }

        // Enviar mail de validación
        $this->enviarMailValidacion($resultado['email'], $resultado['token']);

        Redirect::to('/registro/confirmacion');
    }

    public function confirmacion()
    {
        $this->renderer->render("confirmacion", []);
    }

    public function validarCuenta()
    {
        $token = $_GET['token'] ?? '';

        $usuario = $this->usuarioModel->buscarPorToken($token);

        if (!$usuario) {
            $_SESSION['error'] = 'El enlace de validación es inválido o ya fue usado.';
            header('Location: /login/ver');
            exit();
        }

        $this->usuarioModel->activarCuenta($usuario['id']);

        $_SESSION['error'] = null;
        Redirect::to('/login/ver?validado=1');
    }

    // --- Métodos privados ---

    private function validar($post)
    {
        $errores = [];

        if (empty($post['nombre_completo']))
            $errores[] = 'El nombre completo es obligatorio';

        if (empty($post['anio_nacimiento']) || !is_numeric($post['anio_nacimiento']))
            $errores[] = 'El año de nacimiento es inválido';

        if (empty($post['sexo']) || !in_array($post['sexo'], ['Masculino', 'Femenino', 'Prefiero no cargarlo']))
            $errores[] = 'El sexo es inválido';

        if (empty($post['pais']))
            $errores[] = 'El país es obligatorio';

        if (empty($post['ciudad']))
            $errores[] = 'La ciudad es obligatoria';

        if (empty($post['email']) || !filter_var($post['email'], FILTER_VALIDATE_EMAIL))
            $errores[] = 'El email es inválido';

        if (empty($post['password']) || strlen($post['password']) < 6)
            $errores[] = 'La contraseña debe tener al menos 6 caracteres';

        if ($post['password'] !== $post['repetir_password'])
            $errores[] = 'Las contraseñas no coinciden';

        if (empty($post['username']))
            $errores[] = 'El nombre de usuario es obligatorio';

        return $errores;
    }

    private function subirFoto($archivo)
    {
        $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));

        if (!in_array($extension, $extensionesPermitidas)) {
            return null;
        }

        $nombreArchivo = uniqid('foto_') . '.' . $extension;
        $destino = __DIR__ . '/../public/uploads/' . $nombreArchivo;
        move_uploaded_file($archivo['tmp_name'], $destino);

        return '/public/uploads/' . $nombreArchivo;
    }

    private function enviarMailValidacion($email, $token)
    {
        require_once __DIR__ . '/../vendor/phpmailer/src/PHPMailer.php';
        require_once __DIR__ . '/../vendor/phpmailer/src/SMTP.php';
        require_once __DIR__ . '/../vendor/phpmailer/src/Exception.php';

        $urlBase = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on'
            ? 'https://' . $_SERVER['HTTP_HOST']
            : 'http://' . $_SERVER['HTTP_HOST'];

        $enlace = $urlBase . '/registro/validarCuenta?token=' . $token;

        $mail = new PHPMailer\PHPMailer\PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->CharSet    = 'utf-8';
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->mailUsername;
            $mail->Password   = $this->mailPassword;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true,
                ]
            ];

            $mail->setFrom($this->mailUsername, 'QuizMaster');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Validá tu cuenta en QuizMaster';
            $mail->Body    = "
                <h2>¡Bienvenido a QuizMaster!</h2>
                <p>Hacé click en el siguiente enlace para activar tu cuenta:</p>
                <a href='{$enlace}' style='background:#ff9800;color:white;padding:12px 24px;border-radius:25px;text-decoration:none;font-weight:bold;'>
                    Activar mi cuenta
                </a>
                <p style='margin-top:20px;color:#888;font-size:12px;'>
                    Si no te registraste en QuizMaster, ignorá este mail.
                </p>
            ";

            $mail->send();
        } catch (Exception $e) {
            // Si el mail falla, el registro igual se completa
            error_log('Error al enviar mail: ' . $mail->ErrorInfo);
        }
    }
}
